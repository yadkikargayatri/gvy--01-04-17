﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ORS.BL;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLib;
using System.Data.SqlClient;

namespace ProjectNew
{
    public partial class EmployerRegistration : Form
    {
        public EmployerRegistration()
        {
            InitializeComponent();
        }
        Validations validationObj = new Validations();
        private void btnERSubmit_Click(object sender, EventArgs e)
        {
            frmHomePage frm = new frmHomePage();
            frm.Show();
            this.Hide();

            try
            {
                ORSEntity jsObj = new ORSEntity();

                jsObj.EFirstName = txtEFName.Text;
                jsObj.ELastName = txtELNmae.Text;
                jsObj.ECompanyName = txtECName.Text;
                jsObj.EDesignation = txtEdesignation.Text;
                jsObj.ELocation = txtELocation.Text;
                jsObj.EPhoneNo = Convert.ToInt64(txtEContactNo.Text);
                jsObj.EEmailAddress = txtEEmailAdd.Text;
                jsObj.EPassword = txtEPassword.Text;

                validationObj.AddEmployeeDetails(jsObj);

            }
            catch (CustomException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void EmployerRegistration_Load(object sender, EventArgs e)
        {

        }
    }
}
