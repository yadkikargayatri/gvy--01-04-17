﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ORS.Entity;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using ORS.ExceptionLib;


namespace ORS.DAL
{
    public class Operations
    {
        SqlConnection connection;
        SqlDataReader reader;

         public Operations()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ORS"].ConnectionString;
            connection = new SqlConnection(connectionString);
        }

         public bool AddJobSeekerPDetails(ORSEntity jobj)
         {
             try
             {
                 bool jsAdded = false;
                 SqlCommand cmdAdd = new SqlCommand("AddJobseekers", connection);
                 cmdAdd.CommandType = CommandType.StoredProcedure;
                 cmdAdd.Parameters.AddWithValue("@FirstName ", jobj.JFirstName);
                 cmdAdd.Parameters.AddWithValue("@MiddleName", jobj.JMiddleName);
                 cmdAdd.Parameters.AddWithValue("@LastName", jobj.JLastName);
                 cmdAdd.Parameters.AddWithValue("@EmailAddress", jobj.JEmailAddress);
                 cmdAdd.Parameters.AddWithValue("@JobSeekersAddress", jobj.JAddress);
                 cmdAdd.Parameters.AddWithValue("@Password", jobj.JPassword);
              //   cmdAdd.Parameters.AddWithValue("@", jobj.JCnfPassword);
                 cmdAdd.Parameters.AddWithValue("@DOB", jobj.JDOB);
                 cmdAdd.Parameters.AddWithValue("@ContactNo", jobj.JPhoneNo);
                 cmdAdd.Parameters.AddWithValue("@Gender", jobj.JGender);
                 cmdAdd.Parameters.AddWithValue("@MarraigeStatus", jobj.JMaritalStatus);
               
                 if (connection.State == ConnectionState.Closed)
                     connection.Open();
                 int result = cmdAdd.ExecuteNonQuery();

                 if (result > 0)
                     jsAdded = true;
                 return jsAdded;
             }
             catch (CustomException)
             {
                 throw;
             }
             catch (SqlException)
             {
                 throw;
             }
             catch (Exception)
             {
                 throw;
             }
             finally
             {
                 connection.Close();
             }
         }

         

         public bool AddJobSeekerQDetails(ORSEntity jobj)
         {
             try
             {
                 bool jsAdded = false;
                 SqlCommand cmdAdd = new SqlCommand("JobseekersQualificationDetails", connection);
                 cmdAdd.CommandType = CommandType.StoredProcedure;
                 cmdAdd.Parameters.AddWithValue("@Degree", jobj.Degree);
                 cmdAdd.Parameters.AddWithValue("@Branch", jobj.Branch);
                 cmdAdd.Parameters.AddWithValue("@Passingyear", jobj.PassingYr);
                 cmdAdd.Parameters.AddWithValue("@Percentage", jobj.Percentage);
                 cmdAdd.Parameters.AddWithValue("@UniversityName", jobj.UniversityName);
                 cmdAdd.Parameters.AddWithValue("@JobSeekerID", jobj.JobSeekerID);
                 
              
                 if (connection.State == ConnectionState.Closed)
                     connection.Open();
                 int result = cmdAdd.ExecuteNonQuery();

                 if (result > 0)
                     jsAdded = true;
                 return jsAdded;
             }
             catch (CustomException)
             {
                 throw;
             }
             catch (SqlException)
             {
                 throw;
             }
             catch (Exception)
             {
                 throw;
             }
             finally
             {
                 connection.Close();
             }
         }

         public bool AddEmployeeDetails(ORSEntity jobj)
         {
             try
             {
                 bool jsAdded = false;
                 SqlCommand cmdAdd = new SqlCommand("ORSGroup6AddEmployee", connection);
                 cmdAdd.CommandType = CommandType.StoredProcedure;
                 cmdAdd.Parameters.AddWithValue("@FirstName ", jobj.EFirstName);
                 cmdAdd.Parameters.AddWithValue("@LastName", jobj.ELastName);
                 cmdAdd.Parameters.AddWithValue("@EmailAddress", jobj.EEmailAddress);
                 cmdAdd.Parameters.AddWithValue("@Companyname", jobj.ECompanyName);
                 cmdAdd.Parameters.AddWithValue("@Password", jobj.EPassword);
                 cmdAdd.Parameters.AddWithValue("@Designation", jobj.EDesignation);
                 cmdAdd.Parameters.AddWithValue("@ContactNo", jobj.EPhoneNo);
                 cmdAdd.Parameters.AddWithValue("@Location", jobj.ELocation);
            
                 if (connection.State == ConnectionState.Closed)
                     connection.Open();
                 int result = cmdAdd.ExecuteNonQuery();

                 if (result > 0)
                     jsAdded = true;
                 return jsAdded;
             }
             catch (CustomException)
             {
                 throw;
             }
             catch (SqlException)
             {
                 throw;
             }
             catch (Exception)
             {
                 throw;
             }
             finally
             {
                 connection.Close();
             }
         }

         public DataTable VerifyJS()
         {
             try
             {
                 SqlCommand cmdVerifyEmployee = new SqlCommand("JobSeekerVerification", connection);
                 cmdVerifyEmployee.CommandType = CommandType.StoredProcedure;

                 SqlDataAdapter da = new SqlDataAdapter(cmdVerifyEmployee);
                 DataTable dt = new DataTable();
                 da.Fill(dt);
                 return dt;
             }
             catch (CustomException)
             {
                 throw;
             }
             catch (SqlException)
             {
                 throw;
             }
             catch (Exception)
             {
                 throw;
             }
             finally
             {
                 connection.Close();
             }
         }


         public bool AddJobs(ORSEntity jobj)
         {
             try
             {
                 bool jobsAdded = false;
                 SqlCommand cmdAdd = new SqlCommand("AddJobs", connection);
                 cmdAdd.CommandType = CommandType.StoredProcedure;
                 cmdAdd.Parameters.AddWithValue("@CompanyName", jobj.DCompanyName);
                 cmdAdd.Parameters.AddWithValue("@Post", jobj.DPost);
                 cmdAdd.Parameters.AddWithValue("@Vacancies", jobj.DVacancies);
                 cmdAdd.Parameters.AddWithValue("@PostedDate", jobj.DPostedDate);
                 cmdAdd.Parameters.AddWithValue("@LastDate", jobj.DLastDate);
                 cmdAdd.Parameters.AddWithValue("@CompanyDescription", jobj.DDescription);
                 cmdAdd.Parameters.AddWithValue("@JobLocation", jobj.DJobLocation);
                 cmdAdd.Parameters.AddWithValue("@Package", jobj.DPackage);
                 cmdAdd.Parameters.AddWithValue("@Experience", jobj.DExperience);
                 cmdAdd.Parameters.AddWithValue("@EmployeeID", jobj.EmployeeID);

                 if (connection.State == ConnectionState.Closed) 
                     connection.Open();
                 int result = cmdAdd.ExecuteNonQuery();

                 if (result > 0)
                     jobsAdded = true;
                 return jobsAdded;
             }
             catch (CustomException)
             {
                 throw;
             }
             catch (SqlException)
             {
                 throw;
             }
             catch (Exception)
             {
                 throw;
             }
             finally
             {
                 connection.Close();
             }
         }



       
       
    }
}
