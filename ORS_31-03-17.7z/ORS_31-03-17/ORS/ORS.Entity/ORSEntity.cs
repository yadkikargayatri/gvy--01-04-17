﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORS.Entity
{
    public class ORSEntity
    {
        //Personal Details Jobseeker

        public string JFirstName { get; set; }
        public string JMiddleName { get; set; }
        public string JLastName { get; set; }
        public string JEmailAddress { get; set; }
        public string JPassword { get; set; }
        public Int64 JPhoneNo { get; set; }
        public string JAddress { get; set; }
        public DateTime JDOB { get; set; }
        public string JGender { get; set; }
        public string JMaritalStatus { get; set; }

        //Personal Details Jobseeker(used for validation)
        public string JCity { get; set; }
        public string JCountry { get; set; }
        public string JState { get; set; }
        public string JCnfPassword { get; set; }
        public Int32 JPincode { get; set; }

        //JobSeeker Qualification
        public int JobSeekerID { get; set; }
        public string JCurrentDesig { get; set; }
        public string JPrimarySkills { get; set; }
        public string JSecondarySkills { get; set; }
        public string JTrainingAttd { get; set; }
        public string JDesignation { get; set; }
        public string JExperience { get; set; }

        //Employee Details

        public int EmployeeID { get; set; }
        public string EFirstName { get; set; }
        public string EMiddleName { get; set; }
        public string ELastName { get; set; }
        public string ECompanyName { get; set; }
        public string EEmailAddress { get; set; }
        public string EDesignation { get; set; }
        public string ELocation { get; set; }
        public Int64 EPhoneNo { get; set; }
        public string EPassword { get; set; }



        //Qualification Details

        public int QualificationID { get; set; }
        public string Degree { get; set; }
        public string Branch { get; set; }
        public int PassingYr { get; set; }
        public double Percentage { get; set; }
        public string UniversityName { get; set; }

        //JOB Details .....

        public int JobID { get; set; }
        public string DCompanyName { get; set; }
        public string DPost { get; set; }
        public int DVacancies { get; set; }
        public DateTime DPostedDate { get; set; }
        public DateTime DLastDate { get; set; }
        public string DDescription { get; set; }
        public Double DPackage { get; set; }
        public string DJobLocation { get; set; }
        public string DExperience { get; set; }


    }
}
