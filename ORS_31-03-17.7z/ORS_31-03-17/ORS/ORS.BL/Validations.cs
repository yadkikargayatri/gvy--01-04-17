﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLib;
using System.Data;
using System.Data.SqlClient;

namespace ORS.BL
{
    public class Validations
    {
        Operations operationObj = new Operations();


        public bool AddJobSeekerPDetails(ORSEntity jobj)
        {
            bool jsAdded = false;
                jsAdded = operationObj.AddJobSeekerPDetails(jobj);
            return jsAdded;
        }

        public bool AddJobSeekerQDetails(ORSEntity jobj)
        {
            bool jsAdded = false;
            jsAdded = operationObj.AddJobSeekerQDetails(jobj);
            return jsAdded;
        }

        public bool AddEmployeeDetails(ORSEntity jobj)
        {
            bool jsAdded = false;
            jsAdded = operationObj.AddEmployeeDetails(jobj);
            return jsAdded;
        }

        public DataTable VerifyJS()
        {
       
            DataTable jsTable = operationObj.VerifyJS();
            return jsTable;
        }

        public bool AddJobs(ORSEntity jobj)
        {
            bool jobsAdded = false;
            jobsAdded = operationObj.AddJobs(jobj);
            return jobsAdded;
        }
    }
}
