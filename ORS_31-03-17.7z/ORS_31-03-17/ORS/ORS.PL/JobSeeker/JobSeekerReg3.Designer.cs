﻿namespace ProjectNew
{
    partial class JobSeekerReg3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(JobSeekerReg3));
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lab = new System.Windows.Forms.Label();
            this.txtJsPrimSkills = new System.Windows.Forms.TextBox();
            this.txtJsSecSkills = new System.Windows.Forms.TextBox();
            this.txtJsCertiCourses = new System.Windows.Forms.TextBox();
            this.cmbJsExp = new System.Windows.Forms.ComboBox();
            this.txtJsLocation = new System.Windows.Forms.TextBox();
            this.txtJsResume = new System.Windows.Forms.TextBox();
            this.btnCvBrowse = new System.Windows.Forms.Button();
            this.btnJsReg3 = new System.Windows.Forms.Button();
            this.label = new System.Windows.Forms.Label();
            this.txtJsPhoto = new System.Windows.Forms.TextBox();
            this.btnPicBrowse = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.openFileDialog2 = new System.Windows.Forms.OpenFileDialog();
            this.txtJsDesignation = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(513, 61);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(223, 25);
            this.label6.TabIndex = 15;
            this.label6.Text = "Professional Details";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(415, 158);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 24);
            this.label1.TabIndex = 16;
            this.label1.Text = "Primary Skills";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(415, 221);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(148, 24);
            this.label2.TabIndex = 17;
            this.label2.Text = "Secondary Skills";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(415, 277);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(178, 24);
            this.label4.TabIndex = 18;
            this.label4.Text = "Certification courses";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(415, 333);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 24);
            this.label3.TabIndex = 19;
            this.label3.Text = "Designation";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(415, 385);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(97, 24);
            this.label7.TabIndex = 20;
            this.label7.Text = "Exprience";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(415, 434);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(151, 24);
            this.label5.TabIndex = 21;
            this.label5.Text = "Desired Location";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lab
            // 
            this.lab.AutoSize = true;
            this.lab.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab.Location = new System.Drawing.Point(415, 483);
            this.lab.Name = "lab";
            this.lab.Size = new System.Drawing.Size(146, 24);
            this.lab.TabIndex = 22;
            this.lab.Text = "Upload Resume";
            // 
            // txtJsPrimSkills
            // 
            this.txtJsPrimSkills.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJsPrimSkills.Location = new System.Drawing.Point(617, 156);
            this.txtJsPrimSkills.Name = "txtJsPrimSkills";
            this.txtJsPrimSkills.Size = new System.Drawing.Size(177, 26);
            this.txtJsPrimSkills.TabIndex = 23;
            // 
            // txtJsSecSkills
            // 
            this.txtJsSecSkills.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJsSecSkills.Location = new System.Drawing.Point(617, 219);
            this.txtJsSecSkills.Name = "txtJsSecSkills";
            this.txtJsSecSkills.Size = new System.Drawing.Size(177, 26);
            this.txtJsSecSkills.TabIndex = 24;
            // 
            // txtJsCertiCourses
            // 
            this.txtJsCertiCourses.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJsCertiCourses.Location = new System.Drawing.Point(617, 277);
            this.txtJsCertiCourses.Name = "txtJsCertiCourses";
            this.txtJsCertiCourses.Size = new System.Drawing.Size(177, 26);
            this.txtJsCertiCourses.TabIndex = 25;
            // 
            // cmbJsExp
            // 
            this.cmbJsExp.FormattingEnabled = true;
            this.cmbJsExp.Items.AddRange(new object[] {
            "0-1 yrs",
            "1-2 yrs",
            "2-3 yrs",
            "3-4 yrs"});
            this.cmbJsExp.Location = new System.Drawing.Point(617, 390);
            this.cmbJsExp.Name = "cmbJsExp";
            this.cmbJsExp.Size = new System.Drawing.Size(177, 21);
            this.cmbJsExp.TabIndex = 27;
            // 
            // txtJsLocation
            // 
            this.txtJsLocation.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJsLocation.Location = new System.Drawing.Point(617, 434);
            this.txtJsLocation.Name = "txtJsLocation";
            this.txtJsLocation.Size = new System.Drawing.Size(177, 26);
            this.txtJsLocation.TabIndex = 28;
            // 
            // txtJsResume
            // 
            this.txtJsResume.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJsResume.Location = new System.Drawing.Point(617, 483);
            this.txtJsResume.Name = "txtJsResume";
            this.txtJsResume.Size = new System.Drawing.Size(177, 26);
            this.txtJsResume.TabIndex = 29;
            // 
            // btnCvBrowse
            // 
            this.btnCvBrowse.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCvBrowse.Location = new System.Drawing.Point(823, 483);
            this.btnCvBrowse.Name = "btnCvBrowse";
            this.btnCvBrowse.Size = new System.Drawing.Size(96, 26);
            this.btnCvBrowse.TabIndex = 30;
            this.btnCvBrowse.Text = "Browse";
            this.btnCvBrowse.UseVisualStyleBackColor = true;
            this.btnCvBrowse.Click += new System.EventHandler(this.btnCvBrowse_Click);
            // 
            // btnJsReg3
            // 
            this.btnJsReg3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJsReg3.Location = new System.Drawing.Point(559, 635);
            this.btnJsReg3.Name = "btnJsReg3";
            this.btnJsReg3.Size = new System.Drawing.Size(83, 34);
            this.btnJsReg3.TabIndex = 31;
            this.btnJsReg3.Text = "Submit";
            this.btnJsReg3.UseVisualStyleBackColor = true;
            this.btnJsReg3.Click += new System.EventHandler(this.btnJsReg3_Click);
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label.Location = new System.Drawing.Point(415, 538);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(124, 24);
            this.label.TabIndex = 32;
            this.label.Text = "Upload Photo";
            this.label.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // txtJsPhoto
            // 
            this.txtJsPhoto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJsPhoto.Location = new System.Drawing.Point(617, 536);
            this.txtJsPhoto.Name = "txtJsPhoto";
            this.txtJsPhoto.Size = new System.Drawing.Size(177, 26);
            this.txtJsPhoto.TabIndex = 33;
            // 
            // btnPicBrowse
            // 
            this.btnPicBrowse.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPicBrowse.Location = new System.Drawing.Point(823, 536);
            this.btnPicBrowse.Name = "btnPicBrowse";
            this.btnPicBrowse.Size = new System.Drawing.Size(96, 26);
            this.btnPicBrowse.TabIndex = 34;
            this.btnPicBrowse.Text = "Browse";
            this.btnPicBrowse.UseVisualStyleBackColor = true;
            this.btnPicBrowse.Click += new System.EventHandler(this.btnPicBrowse_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // openFileDialog2
            // 
            this.openFileDialog2.FileName = "openFileDialog2";
            // 
            // txtJsDesignation
            // 
            this.txtJsDesignation.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJsDesignation.Location = new System.Drawing.Point(617, 333);
            this.txtJsDesignation.Name = "txtJsDesignation";
            this.txtJsDesignation.Size = new System.Drawing.Size(177, 26);
            this.txtJsDesignation.TabIndex = 36;
            // 
            // JobSeekerReg3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1184, 762);
            this.Controls.Add(this.txtJsDesignation);
            this.Controls.Add(this.btnPicBrowse);
            this.Controls.Add(this.txtJsPhoto);
            this.Controls.Add(this.label);
            this.Controls.Add(this.btnJsReg3);
            this.Controls.Add(this.btnCvBrowse);
            this.Controls.Add(this.txtJsResume);
            this.Controls.Add(this.txtJsLocation);
            this.Controls.Add(this.cmbJsExp);
            this.Controls.Add(this.txtJsCertiCourses);
            this.Controls.Add(this.txtJsSecSkills);
            this.Controls.Add(this.txtJsPrimSkills);
            this.Controls.Add(this.lab);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label6);
            this.DoubleBuffered = true;
            this.Name = "JobSeekerReg3";
            this.Text = "JobSeekerReg3";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lab;
        private System.Windows.Forms.TextBox txtJsPrimSkills;
        private System.Windows.Forms.TextBox txtJsSecSkills;
        private System.Windows.Forms.TextBox txtJsCertiCourses;
        private System.Windows.Forms.ComboBox cmbJsExp;
        private System.Windows.Forms.TextBox txtJsLocation;
        private System.Windows.Forms.TextBox txtJsResume;
        private System.Windows.Forms.Button btnCvBrowse;
        private System.Windows.Forms.Button btnJsReg3;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.TextBox txtJsPhoto;
        private System.Windows.Forms.Button btnPicBrowse;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog2;
        private System.Windows.Forms.TextBox txtJsDesignation;
    }
}