﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ORS.ExceptionLib;
using ORS.DAL;
using ORS.BL;
using ORS.Entity;

namespace ProjectNew
{
    public partial class frmHomePage : Form
    {
        Validations validationsObj = new Validations();
        private int imageNumber = 1;

        private void loadNextImage()
        {
            if (imageNumber == 4)
            {
                imageNumber = 1;
            }
            picBox1.Load(string.Format(@"D:\Project\ORS\ORS.PL\Images\Img{0}.jpg", imageNumber));
            imageNumber++;
        }

        public static string Euser = null;
        public static string JSuser = null;
        public frmHomePage()
        {
            InitializeComponent();
        }

        private void btnJsLogin_Click(object sender, EventArgs e)
        {
            string uname = txtJsUserName.Text;
            string pass = txtJsPassword.Text;
            if (uname == "b" && pass == "123")
            {
                JSuser = txtJsUserName.Text;
               // this.Hide();
                ShowInTaskbar = false;
                Visible = false;
                JobSeeker frm = new JobSeeker();
                frm.Show();
            }
            else
            {
                MessageBox.Show("Please enter correct username and password");
                txtJsUserName.Text = "";
                txtJsPassword.Text = "";
                txtJsUserName.Focus();
            }  
        }

        private void btnELogin_Click(object sender, EventArgs e)
        {
            string uname = txtEUserName.Text;
            string pass = txtEPassword.Text;
            if (uname == "emp" && pass == "123")
            {
                Euser = txtEUserName.Text;
                this.Hide();
                //ShowInTaskbar = false;
                //Visible = false;
                Employer frm = new Employer();
                frm.Show();
            }
            else
            {
                MessageBox.Show("Please enter correct username and password");
                txtEUserName.Text = "";
                txtEPassword.Text = "";
                txtEUserName.Focus();
            }  
        }

        private void frmHomePage_Load(object sender, EventArgs e)
        {

        }
        public string UserName // on LoginForm
        {
            get { return txtEUserName.Text; }
        }
        //private void button1_Click(object sender, EventArgs e)
        //{

        //}

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            loadNextImage();
        }

        private void linkLblJs_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            JobSeekerReg1 frm = new JobSeekerReg1();
            frm.Show();
            this.Hide();

        }

        private void lin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            EmployerRegistration frm = new EmployerRegistration();
            frm.Show();
            this.Hide();
        }
    }
}
